################################################
##Thresholds de expression para LOF y GOFs
################################################

threshold_MaxExpresion<-10##5##10##If it is above this threshold, considerably expressed gene
threshold_MinExpresion<-1##If a gene expresion below this threshold, not considerably expressed gene
