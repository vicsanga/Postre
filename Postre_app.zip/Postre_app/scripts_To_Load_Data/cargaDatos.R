##Deprecated script
##Now instead of this, load MultiDataList object



